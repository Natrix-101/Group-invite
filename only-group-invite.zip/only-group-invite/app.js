const SteamUser = require('steam-user');
const client = new SteamUser();
const fs = require('fs');
const users = require('./users.json');
const rl = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("Username: ", username => {
  rl.question("Password: ", password => {
    client.logOn({
      accountName: username,
      password: password,
      logonID: 34
    });
  });
});

client.on('steamGuard', (domain, callback) => {
  rl.question("Steam Guard Code: ", callback);
});

client.on('error', error => {
  console.error(error);
});

client.on('friendsList', () => {
  waitForChoice();
});

const waitForChoice = () => {
    rl.question("Press enter to invite users. ", () => {
      invite();
    });
}

const invite = () => {
  let group = "103582791466839850";
  let dontinvite = [];
  if(users.hasOwnProperty(group))
    dontinvite = users[group];
  else
    users[group] = [];
  let friends = client.myFriends;
  let sent = 0;
  let queue = [];
  let finished = () => {
    fs.writeFile("users.json", JSON.stringify(users), error => {
      if(error)
        return console.error(error);
      waitForChoice();
    });
  }
  let next = () => {
    let friend = queue[0];
    if(!friend)
      return finished();
    queue.splice(0, 1);
    client.inviteToGroup(friend, group);
    setTimeout(next, 2500);
  }
  for(let friend in friends) {
    if(sent >= 100)
      break;
    if(friends.hasOwnProperty(friend)) {
      if(friends[friend] == SteamUser.EFriendRelationship.Friend && dontinvite.indexOf(friend) < 0) {
        users[group].push(friend);
        queue.push(friend);
        sent++;
      }
    }
  }
  next();
  console.log("Sending " + sent + " group invites.");
}
